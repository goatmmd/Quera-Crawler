from setuptools import setup

setup(
    name='Get_HTTP',
    version='0.1',
    describtion='Some Sample Describtio',
    url='#',
    author='Mohammad',
    author_mail='goat@gamil.com',
    license='MIT',
    package=['adv'],
    zip_safe=False
)
